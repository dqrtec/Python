n = int(input('Digite um número:'))
for i in range(0,n+1):
	print('2 elevado a ', i, 'é', 2**i)