continua = True
produto = 1
while continua:
    print('Digite um valor ou 0 para sair')
