cont = 0
while cont < 20:
    print(2**cont)
    cont = cont + 1
