n = 0
soma = 0
cont = 0

while n >= 0:
    n = float(input('Numeros negativos saem do programa\nDigite um número POSITIVO:'))
    if n >= 0:
        soma = soma + n
        cont = cont + 1
if cont == 0:
    print('Você não digitou nenhum número.')
else:
    media = soma/cont
    print('A média entre os números é', media)
